import consts


class Snake:
    dx = {'UP': 0, 'DOWN': 0, 'LEFT': -1, 'RIGHT': 1}
    dy = {'UP': -1, 'DOWN': 1, 'LEFT': 0, 'RIGHT': 0}

    def __init__(self, keys, game, pos, color, direction):
        self.keys = keys
        self.cells = [pos]
        self.game = game
        self.game.add_snake(self)
        self.color = color
        self.direction = direction
        game.get_cell(pos).set_color(color)

    @staticmethod
    def reverse_direction(direction):
        if direction == "LEFT":
            return "RIGHT"
        if direction == "RIGHT":
            return "LEFT"
        if direction == "UP":
            return "DOWN"
        if direction == "DOWN":
            return "UP"

    def get_head(self):
        return self.cells[-1]

    def val(self, x):
        if x < 0:
            x += self.game.size

        if x >= self.game.size:
            x -= self.game.size

        return x

    def next_move(self):
        x, y = self.get_head()
        x, y = self.next_pos_snake(x, y)
        next_cell = self.game.get_cell([x, y])
        if next_cell.color == consts.block_color or next_cell.color == self.color:
            self.game.kill(self)
            return
        if next_cell.color == consts.back_color:
            self.cells.insert(len(self.cells), (x, y))
            self.game.get_cell(self.cells[0]).set_color(consts.back_color)
            self.cells.pop(0)
        if next_cell.color == consts.fruit_color:
            self.cells.insert(len(self.cells), (x, y))
        next_cell.set_color(self.color)

    def handle(self, keys):
        for k in keys:
            if k in self.keys:
                if self.keys[k] != self.reverse_direction(self.direction):
                    self.direction = self.keys[k]

    def next_pos_snake(self, x, y):
        if self.direction == "UP":
            if y - 1 < 0:
                return x, consts.table_size - 1
            return x, y - 1
        if self.direction == "DOWN":
            if y + 1 >= consts.table_size:
                return x, 0
            return x, y + 1
        if self.direction == "LEFT":
            if x - 1 < 0:
                return consts.table_size - 1, y
            return x - 1, y
        if self.direction == "RIGHT":
            if x + 1 >= consts.table_size:
                return 0, y
            return x + 1, y
